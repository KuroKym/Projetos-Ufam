package br.ufam.edu.icomp.Trabalho1;

public class DespesaMaterialConsumo extends Despesa{
	public DespesaMaterialConsumo(String descricao, double valor) throws NumeroNegativo {
		super(descricao, valor);
	}
}
