package br.edu.icomp.plaintext;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import java.sql.SQLException;
import java.util.ArrayList;


public class ListActivity extends AppCompatActivity {
    private RecyclerView recyclerView;
    private ProjetosAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);

        recyclerView = findViewById(R.id.list_recycler);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        adapter = new ProjetosAdapter(this);
        recyclerView.setAdapter(adapter);
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        adapter.update();
        adapter.notifyDataSetChanged();
    }

    public void buttonAddClick(View view) {
        Intent intent = new Intent(this, EditActivity.class);
        startActivity(intent);
    }

    public void buttonRemoveClick(View view) {
        Intent intent = new Intent(this, RemoveActivity.class);
        startActivity(intent);
    }



}

class ProjetosAdapter extends RecyclerView.Adapter<ProjetosViewHolder> {
    private Context context;
    private ArrayList<Projeto> projetos;
    ProjetoDAO projetoDAO;
    public ProjetosAdapter(Context context) {
        this.context = context;
        projetoDAO = new ProjetoDAO(context);
        update();
    }

    public void update() { projetos = projetoDAO.getList(); }

    public ProjetosViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        ConstraintLayout v = (ConstraintLayout) LayoutInflater
                .from(parent.getContext())
                .inflate(R.layout.list_item, parent, false);
        ProjetosViewHolder vh = new ProjetosViewHolder(v, context);
        return vh;
    }

    public void onBindViewHolder(ProjetosViewHolder holder, int position) {
        holder.name.setText(projetos.get(position).getName());
        holder.valorProjeto.setText("Valor: " + projetos.get(position).getValorProjeto());
        holder.id = projetos.get(position).getId();
    }

    public int getItemCount() { return projetos.size(); }
}

class ProjetosViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
    public Context context;
    public TextView name, professor, valorProjeto, descricao;
    public int id;
    public ProjetosViewHolder(ConstraintLayout v, Context context) {
        super(v);
        this.context = context;
        name = v.findViewById(R.id.itemName);
        valorProjeto = v.findViewById(R.id.itemValor);
        v.setOnClickListener(this);
    }

    public void onClick(View v) {
        Intent intent = new Intent(context, EditActivity.class);
        intent.putExtra("projetoId", this.id);
        context.startActivity(intent);
    }
}

class Projeto {
    private int id;
    private String name;
    private String nomeProfessor;
    private String valorProjeto;
    private String descricao;

    Projeto(int id, String name, String nomeProfessor, String valorProjeto, String descricao) {
        this.id = id;
        this.name = name;
        this.nomeProfessor = nomeProfessor;
        this.valorProjeto = valorProjeto;
        this.descricao = descricao;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getId() {
        return id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setNomeProfessor(String nomeProfessor) {
        this.nomeProfessor = nomeProfessor;
    }

    public String getNomeProfessor() {
        return nomeProfessor;
    }

    public void setValorProjeto(String valorProjeto){
        this.valorProjeto = valorProjeto;
    }

    public String getValorProjeto(){
        return valorProjeto;
    }

    public void setDescricao(String descricao){
        this.descricao = descricao;
    }

    public String getDescricao(){
        return descricao;
    }

}

class ProjetoDAO {
    private Context context;
    private SQLiteDatabase database;

    public ProjetoDAO(Context context) {
        this.context = context;
        this.database = (new Database(context)).getWritableDatabase();
    }

    public ArrayList<Projeto> getList() {
        ArrayList<Projeto> result = new ArrayList<Projeto>();
        String sql = "SELECT * FROM projetos ORDER BY name";
        Cursor cursor = database.rawQuery(sql, null);
        while (cursor.moveToNext()) {
            int id = cursor.getInt(0);
            String name = cursor.getString(1);
            String nomeProfessor = cursor.getString(2);
            String valorProjeto = cursor.getString(3);
            String descricao = cursor.getString(4);

            result.add(new Projeto(id, name, nomeProfessor, valorProjeto, descricao));
        }
        return result;
    }

    public boolean add(Projeto projeto) {
        String sql = "INSERT INTO projetos VALUES (NULL, "
                + "'" + projeto.getName() + "', "
                + "'" + projeto.getNomeProfessor() + "', "
                + "'" + projeto.getValorProjeto() + "', "
                + "'" + projeto.getDescricao() + "')";
        database.execSQL(sql);
        Toast.makeText(context, "Projeto salvo!", Toast.LENGTH_SHORT).show();
        return true;

    }

    public boolean update(Projeto projeto) {
        String sql = "UPDATE projetos SET "
                + "name='" + projeto.getName() + "', "
                + "professor='" + projeto.getNomeProfessor() + "', "
                + "valor='" + projeto.getValorProjeto() + "', "
                + "descricao='" + projeto.getDescricao() + "' "
                + "WHERE id=" + projeto.getId();
        database.execSQL(sql);
        Toast.makeText(context, "Projeto atualizado!", Toast.LENGTH_SHORT).show();
        return true;
    }

    public Projeto get(int id) {
        String sql = "SELECT * FROM projetos WHERE id=" + id;
        Cursor cursor = database.rawQuery(sql, null);
        if (cursor.moveToNext()) {
            String name = cursor.getString(1);
            String professor = cursor.getString(2);
            String valor = cursor.getString(3);
            String descricao = cursor.getString(4);
            return new Projeto(id, name, professor, valor, descricao);
        }
        return null;
    }

    public boolean remove(String nomeProjeto){
        String sql = "DELETE FROM projetos WHERE name='" + nomeProjeto + "'";
        database.execSQL(sql);
        Toast.makeText(context, "Projeto removido!", Toast.LENGTH_SHORT).show();
        return true;
    }
}
