package br.edu.icomp.plaintext;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class Database extends SQLiteOpenHelper {

    public static final int DATABASE_VERSION = 5;
    public static final String DATABASE_NAME = "PlainText.db";
    private static final String SQL_CREATE_PASS = "CREATE TABLE projetos (" +
            "id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, professor TEXT," +
            "valor TEXT, descricao TEXT)";
    private static final String SQL_POPULATE_PASS = "INSERT INTO projetos VALUES " +
            "(NULL, 'Analise da Agua', 'Carlos Gomes', '24000', 'Projeto em analise')";
    private static final String SQL_DELETE_PASS = "DROP TABLE IF EXISTS projetos";

    public Database(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    public void onCreate(SQLiteDatabase db) {
        db.execSQL(SQL_CREATE_PASS);
        db.execSQL(SQL_POPULATE_PASS);
    }

    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL(SQL_DELETE_PASS);
        onCreate(db);
    }
}
