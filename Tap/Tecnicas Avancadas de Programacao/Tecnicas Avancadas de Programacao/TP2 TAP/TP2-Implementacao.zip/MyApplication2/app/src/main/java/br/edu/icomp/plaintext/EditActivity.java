package br.edu.icomp.plaintext;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class EditActivity extends AppCompatActivity {
    private ProjetoDAO projetoDAO;
    private int projetoId;
    private TextView editName, editProfessor, editValor, editDescricao;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit);
        editName = findViewById(R.id.addName);
        editProfessor = findViewById(R.id.addProfessor);
        editValor = findViewById(R.id.addValor);
        editDescricao = findViewById(R.id.addNotes);
        projetoDAO = new ProjetoDAO(this);
        Intent intent = getIntent();
        projetoId = intent.getIntExtra("passwordId", -1);


        if (projetoId != -1) {
            Projeto projeto = projetoDAO.get(projetoId);
            editName.setText(projeto.getName());
            editProfessor.setText(projeto.getNomeProfessor());
            editValor.setText(projeto.getValorProjeto());
            editDescricao.setText(projeto.getDescricao());
        }

    }

    public void salvarClicado(View view) {
        Projeto projeto = new Projeto(projetoId, editName.getText().toString(),
                editProfessor.getText().toString(), editValor.getText().toString(),
                editDescricao.getText().toString());
        boolean result;
        if (projetoId == -1) result = projetoDAO.add(projeto);
        else
            result = projetoDAO.update(projeto);
        if (result) finish();
    }
}