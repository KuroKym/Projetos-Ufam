package br.edu.icomp.plaintext;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class RemoveActivity extends AppCompatActivity {
    private ProjetoDAO projetoDAO;
    private TextView removerNome;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_remove);

        removerNome = findViewById(R.id.removerNome);
        projetoDAO = new ProjetoDAO(this);
    }

    public void removerClicado(View view) {
        projetoDAO.remove(removerNome.getText().toString());
        finish();
    }
}